# Revisão

Usar a api de deputados:
api: https://dadosabertos.camara.leg.br/swagger/api.html
baseURL: https://dadosabertos.camara.leg.br/api/v2

<ol>
  <li>Criar um projeto chamado revisao</li>
  <li> Criar uma página com a listagem de todos os deputados, conforme imagem 1</li>
  <li>Ao cicar em um deputado, ir para a página de detalhes, conforme imagem 2</li>
</ol>

- imagem 1

  <img alt="img" src="revisao/public/imagem1.png"/>

- imagem 2

<img alt="img" src="../public/imagem2.png"/>
