import Pagina from "@/components/Pagina";

import React from "react";

const index = () => {
  return <Pagina></Pagina>;
};

export default index;
