import Pagina from "@/components/Pagina";
import React from "react";

const index = () => {
  return <Pagina titulo="Academico"></Pagina>;
};

export default index;
